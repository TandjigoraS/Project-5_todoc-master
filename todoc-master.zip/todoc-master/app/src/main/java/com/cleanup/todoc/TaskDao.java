package com.cleanup.todoc;

import androidx.lifecycle.LiveData;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.cleanup.todoc.model.Task;

import java.util.List;

@androidx.room.Dao
public interface TaskDao {
    @Insert
    void insert (Task task);

    @Query("DELETE FROM task_table")
    void deleteAllTask();

    @Query("SELECT * FROM task_table")
    LiveData<List<Task>> getListTasks();
}

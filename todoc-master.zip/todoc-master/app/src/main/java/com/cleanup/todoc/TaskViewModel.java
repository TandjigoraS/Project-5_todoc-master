package com.cleanup.todoc;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.cleanup.todoc.model.Task;

import java.util.List;

public class TaskViewModel extends AndroidViewModel {
    private TaskRepository mTaskRepository;
    private final LiveData<List<Task>> mListTasks;

    public TaskViewModel(@NonNull Application application) {
        super(application);
        mTaskRepository = new TaskRepository(application);
        mListTasks = mTaskRepository.getListTasks();

    }

    public LiveData<List<Task>> getListTasks() {
        return mListTasks;
    }

    public void insert (Task task) { mTaskRepository.insert(task);}
}

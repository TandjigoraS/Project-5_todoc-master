package com.cleanup.todoc;


import android.app.Application;

import androidx.lifecycle.LiveData;

import com.cleanup.todoc.model.Task;

import java.util.List;

public class TaskRepository {

    private TaskDao mTaskDao;
    private LiveData<List<Task>> mListTasks;

    public TaskRepository(Application application) {
        MyRoomDatabase database = MyRoomDatabase.getDatabase(application);
        mTaskDao = database.mTaskDao();
        mListTasks = mTaskDao.getListTasks();
    }

    public LiveData<List<Task>> getListTasks() {
        return mListTasks;
    }

    void insert(final Task task) {
        MyRoomDatabase.databaseWriteExecutor.execute(() -> {mTaskDao.insert(task);});

    }
}
